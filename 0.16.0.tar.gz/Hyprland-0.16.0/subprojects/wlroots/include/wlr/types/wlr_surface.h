#warning "wlr/types/wlr_surface.h has been deprecated and will be removed in the future. Use wlr/types/wlr_compositor.h and wlr/types/wlr_subcompositor.h."

#include <wlr/types/wlr_compositor.h>
#include <wlr/types/wlr_subcompositor.h>
