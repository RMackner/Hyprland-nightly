#ifndef UTIL_TOKEN_H
#define UTIL_TOKEN_H

#include <stdbool.h>

#define TOKEN_STRLEN 33
bool generate_token(char out[static TOKEN_STRLEN]);

#endif
