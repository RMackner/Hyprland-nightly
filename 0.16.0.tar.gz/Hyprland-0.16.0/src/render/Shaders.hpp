#pragma once

#include "shaders/Textures.hpp"
#include "shaders/Shadow.hpp"
#include "shaders/Border.hpp"