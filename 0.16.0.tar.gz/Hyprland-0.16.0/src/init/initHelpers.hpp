#pragma once

#include "../defines.hpp"

namespace Init {
    bool isSudo();
};