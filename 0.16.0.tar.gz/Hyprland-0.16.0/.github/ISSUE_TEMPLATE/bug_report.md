---
name: Bug report
about: Found a bug? Report it here!
title: ''
labels: bug
assignees: ''

---

Please consult the issue guidelines at
https://github.com/vaxerski/Hyprland/blob/main/docs/ISSUE_GUIDELINES.md
BEFORE submitting.
